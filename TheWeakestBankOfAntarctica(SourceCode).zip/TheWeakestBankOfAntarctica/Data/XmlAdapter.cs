﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TheWeakestBankOfAntarctica.Model;
using System.IO;
using System.Xml.Serialization;

namespace TheWeakestBankOfAntarctica.Data
{
    public static class XmlAdapter
    {
        private static string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
        private static string projectDirectory = Directory.GetParent(baseDirectory).Parent.Parent.FullName;

        private static string relativeFilePathForCustomerData = Path.Combine(projectDirectory, "BankDataFiles\\Customers\\CustomerData.xml");
        private static string relativeFilePathForTransactions = Path.Combine(projectDirectory, "BankDataFiles\\Transactions\\");
        private static string relativeFilePathForAccountsData = Path.Combine(projectDirectory, "BankDataFiles\\Accounts\\AccountsData.xml");
        public static void SerializeCustomerDataToXml(List<Customer> customers)
        {
            var serializer = new XmlSerializer(typeof(List<Customer>));
            string tempFilePath = relativeFilePathForCustomerData + ".tmp";

            try
            {
                // Write to a temp file first
                using (TextWriter writer = new StreamWriter(tempFilePath))
                {
                    serializer.Serialize(writer, customers);
                }

                // Rename by copying the temp file to the destination and then deleting the temp file
                if (File.Exists(relativeFilePathForCustomerData))
                {
                    File.Delete(relativeFilePathForCustomerData); // Delete the original file if it exists
                }

                File.Copy(tempFilePath, relativeFilePathForCustomerData); // Copy temp file to the destination
                File.Delete(tempFilePath); // Delete the temporary file after successful copy
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error serializing customer data: {ex.Message}");
                if (File.Exists(tempFilePath)) File.Delete(tempFilePath); // Clean up temp file if it exists
            }
        }


        public static void SerializeAccountDataToXml(List<Account> accounts)
        {
            var serializer = new XmlSerializer(typeof(List<Account>));
            string tempFilePath = relativeFilePathForAccountsData + ".tmp";

            try
            {
                // Write to a temp file first
                using (TextWriter writer = new StreamWriter(tempFilePath))
                {
                    serializer.Serialize(writer, accounts);
                }

                // Rename by copying the temp file to the destination and then deleting the temp file
                if (File.Exists(relativeFilePathForAccountsData))
                {
                    File.Delete(relativeFilePathForAccountsData); // Delete the original file if it exists
                }

                File.Copy(tempFilePath, relativeFilePathForAccountsData); // Copy temp file to the destination
                File.Delete(tempFilePath); // Delete the temporary file after successful copy
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error serializing account data: {ex.Message}");
                if (File.Exists(tempFilePath)) File.Delete(tempFilePath); // Clean up temp file if it exists
            }
        }


        public static void SearlizeTransaction(Transaction transaction)
        {
            string updatedPath = Path.Combine(relativeFilePathForTransactions, transaction.TransactionId + ".xml");
            string tempFilePath = updatedPath + ".tmp";

            try
            {
                var serializer = new XmlSerializer(typeof(Transaction));
                // Write to a temporary file first
                using (TextWriter writer = new StreamWriter(tempFilePath))
                {
                    serializer.Serialize(writer, transaction);
                }

                // Handle manual rename by copying and deleting
                if (File.Exists(updatedPath))
                {
                    File.Delete(updatedPath); // Delete original file if it exists
                }

                File.Copy(tempFilePath, updatedPath); // Copy temp file to the final path
                File.Delete(tempFilePath); // Delete temporary file after successful copy
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error serializing transaction {transaction.TransactionId}: {ex.Message}");
                if (File.Exists(tempFilePath)) File.Delete(tempFilePath); // Clean up temp file if it exists
            }
        }


        public static List<Transaction> DeserializeTransaction(string filepath)
        {
            List<Transaction> transactions = new List<Transaction>();

            try
            {
                // Get all XML files in the specified folder
                string[] xmlFiles = Directory.GetFiles(filepath, "*.xml");
                int batchSize = 10; // Adjust batch size for efficient handling

                var serializer = new XmlSerializer(typeof(Transaction));

                for (int i = 0; i < xmlFiles.Length; i += batchSize)
                {
                    List<string> batchFiles = new List<string>();

                    // Collect the batch of files 
                    for (int j = i; j < Math.Min(i + batchSize, xmlFiles.Length); j++)
                    {
                        batchFiles.Add(xmlFiles[j]);
                    }

                    // Process files in batches synchronously
                    foreach (string filePath in batchFiles)
                    {
                        try
                        {
                            using (StreamReader reader = new StreamReader(filePath))
                            {
                                Transaction transaction = (Transaction)serializer.Deserialize(reader);
                                transactions.Add(transaction);
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Failed to deserialize file {filePath}: {ex.Message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing transactions: {ex.Message}");
            }

            return transactions;
        }


    }
}
    


