﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheWeakestBankOfAntarctica.View
{
    public class AccessController
    {
        // Sensitive information now retrieved from environment variables, with a fallback
        static string storedUsername = Environment.GetEnvironmentVariable("APP_USERNAME") ?? "Admin";
        static string storedPassword = Environment.GetEnvironmentVariable("APP_PASSWORD") ?? "Admin123";
        static int failedAttempts = 0;  // To keep track of failed attempts
        const int maxFailedAttempts = 3; // Maximum allowed failed login attempts

        public static bool Login(string login, string password)
        {
            if (failedAttempts >= maxFailedAttempts)
            {
                Console.WriteLine("Account locked due to too many failed login attempts.");
                return false; // Account locked
            }

            // Compare entered credentials with stored credentials
            if (login == storedUsername && password == storedPassword)
            {
                failedAttempts = 0; // Reset failed attempts after successful login
                return true; // Login successful
            }
            else
            {
                failedAttempts++; // Increment the failed attempts counter
                Console.WriteLine("Invalid credentials. Please try again."); // Generic error message
                return false; // Login failed
            }
        }
    }
}


   