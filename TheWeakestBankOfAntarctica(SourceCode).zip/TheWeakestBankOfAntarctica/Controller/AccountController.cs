﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TheWeakestBankOfAntarctica.Data;
using TheWeakestBankOfAntarctica.Model;

namespace TheWeakestBankOfAntarctica.Controller
{
    public static class AccountController
    {
        public static void CreateNewSavingsAccount(Customer customer, double balance)
        {
            // Create a new savings account
            Account account = new Account(TypeOfAccount.Savings, customer.CustomerId, balance);
            // DataAdapter.SaveAccount(account); // Uncomment this line to persist the account
        }

        public static void CreateNewCheckingAccount(Customer customer, double balance) 
        {
            // Create a new checking account
            Account account = new Account(TypeOfAccount.Checking, customer.CustomerId, balance);
            // DataAdapter.SaveAccount(account); // Uncomment this line to persist the account
        }

        public static List<Account> GetAllAccountsByCustomerOfficialId(string govId)
        {
            List<Account> accounts = DataAdapter.GetAccountOwners(govId);
            return accounts;
        }


        public static Account GetAccountByAccountNumber(string accountNumber)
        {
           return DataAdapter.GetAccountByAccountNumber(accountNumber);
        }

        public static bool CloseAccount(string accountNumber)
        {
            // Attempt to close the account using the DataAdapter
            string result = DataAdapter.CloseAccount(accountNumber);

            // Check if result matches the account number, indicating success
            if (result.Equals(accountNumber, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"Account {accountNumber} closed successfully.");
                return true; // Indicate success
            }
            else
            {
                Console.WriteLine($"Failed to close account {accountNumber}: {result}");
                return false; // Indicate failure
            }
        }




    }
}
