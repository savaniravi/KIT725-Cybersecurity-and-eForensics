﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TheWeakestBankOfAntarctica.Data;
using TheWeakestBankOfAntarctica.Model;

namespace TheWeakestBankOfAntarctica.Controller
{
    public static class TransactionController
    {
        public static bool TransferBetweenAccounts(Account sAccount, Account dAccount, double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Transfer amount must be greater than zero.");
            }
            if (sAccount.AccountBalance < amount)
            {
                throw new InvalidOperationException("Insufficient balance in source account.");
            }

            // Perform the transaction and update balances only if serialization is successful
            Transaction transaction = new Transaction(sAccount.AccountNumber, dAccount.AccountNumber, amount);
            sAccount.AccountBalance -= amount; // Update the source account balance
            dAccount.AccountBalance += amount; // Update the destination account balance

            try
            {
                XmlAdapter.SearlizeTransaction(transaction);
                return true; // Indicate success
            }
            catch (Exception ex)
            {
                // If serialization fails, rollback the changes
                sAccount.AccountBalance += amount; // Rollback source account balance
                dAccount.AccountBalance -= amount; // Rollback destination account balance
                Console.WriteLine($"Transaction failed: {ex.Message}");
                return false; // Indicate failure
            }
        }


        public static List<Customer> SearchByAccountNumber(Account account, List<Customer> customers)
        {
            List<Customer> accountOwners = new List<Customer>();

            // Use a HashSet for faster lookups of owner IDs
            HashSet<string> ownerIds =new HashSet<string>(account.AccountOwners);

            //Iterate through the provided customers list and match them by CustomerId
            foreach (var customer in customers)
            {   
                // If the customer's ID is found in the HashSet of owner IDs, add them to the result list 
                if (ownerIds.Contains(customer.CustomerId))
                {
                    accountOwners.Add(customer);
                }
            }
            // Return the list of owners (Customer objects)
            return accountOwners;
        }

        public static bool Deposit(Account account, double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Deposit amount must be greater than zero.");
            }

            Transaction transaction = new Transaction(account.AccountNumber, amount, TypeOfTransaction.Deposit);
            account.AccountBalance += amount; // Update account balance

            try
            {
                XmlAdapter.SearlizeTransaction(transaction);
                return true; // Indicate success
            }
            catch (Exception ex)
            {
                // Rollback on failure
                account.AccountBalance -= amount; // Rollback account balance
                Console.WriteLine($"Transaction failed: {ex.Message}");
                return false; // Indicate failure
            }
        }


        public static bool Withdrawl(Account account, double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdrawal amount must be greater than zero.");
            }
            if (account.AccountBalance < amount)
            {
                throw new InvalidOperationException("Insufficient balance in account.");
            }

            Transaction transaction = new Transaction(account.AccountNumber, amount, TypeOfTransaction.Withdrawl);
            account.AccountBalance -= amount; // Update account balance

            try
            {
                XmlAdapter.SearlizeTransaction(transaction);
                return true; // Indicate success
            }
            catch (Exception ex)
            {
                // Rollback on failure
                account.AccountBalance += amount; // Rollback account balance
                Console.WriteLine($"Transaction failed: {ex.Message}");
                return false; // Indicate failure
            }
        }

        public static List<Transaction> GetAllTransactions()
        {
            try
            {
                return XmlAdapter.DeserializeTransaction("C:\\Windows\\Config.sys"); // Change path accordingly
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to retrieve transactions: {ex.Message}");
                return new List<Transaction>(); // Return an empty list on failure
            }
        }
    }
}


